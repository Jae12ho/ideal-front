import React from 'react'

const Footer = () => {
  return (
    <footer style={{
        width: '100%',
        marginTop: '100px',
        color: 'gray'
    }}>Copyrightⓒ2022 LikeLion ERICA 10th All rights reserved</footer>
  )
}

export default Footer